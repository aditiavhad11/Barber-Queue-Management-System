import crypto from "node:crypto";
import { pool } from "../config/db.js";
import {
  addNotification,
  findBookings,
  hydrateBookings,
  rupees,
} from "../models/bookingModel.js";
import {
  isValidEmail,
  isValidPhone,
  isValidName,
  normalizePhone,
} from "../utils/validators.js";

const REBOOK_BLOCK_MINUTES = 30;
const AMOUNT_WINDOW_MINUTES = 15;

const sha256 = (text) => crypto.createHash("sha256").update(text).digest("hex");
const signQuote = (payload) => {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = crypto
    .createHmac("sha256", process.env.JWT_SECRET || "missing-secret")
    .update(body)
    .digest("hex");
  return `${body}.${signature}`;
};
const verifyQuote = (token) => {
  try {
    const [body, signature] = String(token || "").split(".");
    if (!body || !signature) return null;
    const expected = crypto
      .createHmac("sha256", process.env.JWT_SECRET || "missing-secret")
      .update(body)
      .digest("hex");
    if (
      signature.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))
    )
      return null;
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
};

const localDateKey = (date = new Date()) => {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const pick = (type) => parts.find((p) => p.type === type)?.value;
  return `${pick("year")}-${pick("month")}-${pick("day")}`;
};

const localTimeKey = (date = new Date()) => {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const pick = (type) => parts.find((p) => p.type === type)?.value;
  return `${pick("hour")}:${pick("minute")}`;
};

function assertAnnualScheduleAllowsBooking(availability, bookingDate) {
  const schedules =
    availability?.annualSchedules &&
    typeof availability.annualSchedules === "object"
      ? availability.annualSchedules
      : {};
  const item = schedules[bookingDate];
  if (!item) return;
  const type = String(item.type || "closed");
  const note = String(item.note || "").trim();
  if (type === "closed") {
    const suffix = note ? `: ${note}` : ".";
    throw Object.assign(new Error(`This shop is closed today${suffix}`), {
      status: 409,
    });
  }
  if (
    ["half_day", "special_hours"].includes(type) &&
    bookingDate === localDateKey()
  ) {
    const open = String(item.open || "09:00").slice(0, 5);
    const close = String(item.close || "21:00").slice(0, 5);
    const now = localTimeKey();
    if (close <= open || now < open || now >= close) {
      const label = type === "half_day" ? "half-day hours" : "special hours";
      throw Object.assign(
        new Error(
          `This shop is only accepting bookings during ${label} today (${open}-${close}).`,
        ),
        { status: 409 },
      );
    }
  }
}

function beneficiaryFrom(body, customer) {
  const raw = body?.beneficiary || {};
  if (raw.isSelf === false) {
    const person = {
      isSelf: false,
      name: String(raw.name || "").trim(),
      mobile: String(raw.mobile || "").trim(),
      email: String(raw.email || "")
        .trim()
        .toLowerCase(),
    };
    if (!person.name || !isValidName(person.name))
      return {
        error:
          "Enter a valid name (2 to 60 alphabetic characters) for the person being booked for.",
      };
    if (person.mobile && !isValidPhone(person.mobile))
      return { error: "Enter a valid 10-digit mobile number." };
    if (person.email && !isValidEmail(person.email))
      return { error: "Enter a valid email address." };
    return {
      person: {
        ...person,
        mobile: person.mobile ? normalizePhone(person.mobile) : "",
      },
      key: `beneficiary:${person.name.toLowerCase()}|${person.mobile || person.email || ""}`,
    };
  }
  const selfMobile = String(raw.mobile || "").trim();
  if (selfMobile && !isValidPhone(selfMobile)) {
    return { error: "Enter a valid 10-digit mobile number." };
  }
  return {
    person: {
      isSelf: true,
      name: customer.name,
      mobile: selfMobile ? normalizePhone(selfMobile) : "",
      email: customer.email,
    },
    key: `user:${customer.id}`,
  };
}

async function validateSelection(
  connection,
  {
    shopId,
    barberId,
    serviceIds,
    customerId,
    bookingDate,
    scheduledTime = null,
  },
) {
  const [shops] = await connection.query(
    "SELECT id,name,upi_qr_url,availability_json FROM shops WHERE id=? AND status='approved' AND active=1 LIMIT 1",
    [shopId],
  );
  if (!shops.length)
    throw Object.assign(
      new Error("This shop is not accepting bookings right now."),
      { status: 404 },
    );

  const avail =
    typeof shops[0].availability_json === "string"
      ? JSON.parse(shops[0].availability_json || "{}")
      : shops[0].availability_json || {};
  const now = new Date();
  const istParts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(now);
  const part = (type) => istParts.find((item) => item.type === type)?.value;
  const today = `${part("year")}-${part("month")}-${part("day")}`;
  const currentTime = `${part("hour")}:${part("minute")}`;
  const emergencyEnd = avail.temporaryClosure?.endAt
    ? new Date(avail.temporaryClosure.endAt)
    : null;
  const emergencyExpired =
    avail.emergencyClosed && emergencyEnd && emergencyEnd <= new Date();
  if (avail.isOpen === false && !emergencyExpired) {
    throw Object.assign(new Error("This shop is currently closed."), {
      status: 409,
    });
  }
  const bookingWeekday = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Kolkata",
    weekday: "short",
  }).format(new Date(`${bookingDate}T12:00:00Z`));
  const annual = avail.annualSchedules?.[bookingDate];
  const schedule = avail.schedule?.[bookingWeekday];
  const manualOpenToday = bookingDate === today && avail.isOpen === true;
  if (
    !manualOpenToday &&
    (annual?.type === "closed" || (!annual && schedule?.closed))
  ) {
    throw Object.assign(
      new Error("This shop is closed on the selected booking date."),
      {
        status: 409,
      },
    );
  }
  if (bookingDate === today) {
    const override = avail.operationalHours;
    const shifts =
      override?.enabled && (!override.date || override.date === today)
        ? [{ open: override.open, close: override.close }]
        : annual && ["half_day", "special_hours"].includes(annual.type)
          ? [{ open: annual.open, close: annual.close }]
          : Array.isArray(schedule?.shifts) && schedule.shifts.length
            ? schedule.shifts
            : [
                {
                  open: schedule?.open || "09:00",
                  close: schedule?.close || "21:00",
                },
              ];
    if (
      (!manualOpenToday &&
        (annual?.type === "closed" || (!annual && schedule?.closed))) ||
      (!manualOpenToday &&
        !shifts.some(
          (shift) => currentTime >= shift.open && currentTime < shift.close,
        ))
    ) {
      throw Object.assign(
        new Error("This shop is outside its booking hours right now."),
        { status: 409 },
      );
    }
  }
  const tc = avail?.temporaryClosure;
  if (tc && tc.active) {
    if (tc.endAt && new Date(tc.endAt) <= new Date()) {
      // The server-side timestamp is authoritative; an expired hour closure
      // must not keep blocking new bookings because the UI was not refreshed.
    } else {
      const start = tc.startDate || today;
      const end = tc.endDate || "";
      const hourClosureApplies =
        tc.startAt &&
        bookingDate === String(tc.startAt).slice(0, 10) &&
        new Date(tc.startAt) <= new Date() &&
        (!tc.endAt || new Date() < new Date(tc.endAt));
      const dayClosureApplies =
        !tc.startAt && bookingDate >= start && (!end || bookingDate <= end);
      if (hourClosureApplies || dayClosureApplies) {
        const reasonPart = tc.reason ? ` (${tc.reason})` : "";
        const untilPart = end ? ` until ${end}` : "";
        throw Object.assign(
          new Error(
            `This shop is temporarily closed for emergency${reasonPart}${untilPart}.`,
          ),
          { status: 409 },
        );
      }
    }
  }
  if (!manualOpenToday) assertAnnualScheduleAllowsBooking(avail, bookingDate);

  if (!shops[0].upi_qr_url)
    throw Object.assign(new Error("This shop can't take bookings yet."), {
      status: 409,
    });

  const [barbers] = await connection.query(
    "SELECT id,status,queue_limit FROM barbers WHERE id=? AND shop_id=? LIMIT 1",
    [barberId, shopId],
  );
  if (!barbers.length)
    throw Object.assign(
      new Error("Selected barber was not found in this shop."),
      { status: 404 },
    );
  if (barbers[0].status !== "Available")
    throw Object.assign(new Error("This barber is not available right now."), {
      status: 409,
    });

  const marks = serviceIds.map(() => "?").join(",");
  const [services] = await connection.query(
    `SELECT id,name,price,duration_minutes FROM services WHERE shop_id=? AND enabled=1 AND id IN (${marks})`,
    [shopId, ...serviceIds],
  );
  if (services.length !== serviceIds.length)
    throw Object.assign(
      new Error("One or more selected services are not available."),
      { status: 400 },
    );

  let unavailable;
  try {
    [unavailable] = await connection.query(
      `SELECT u.service_id, s.name, u.reason
       FROM service_unavailability u
       JOIN services s ON s.id=u.service_id AND s.shop_id=u.shop_id
       WHERE u.shop_id=? AND u.unavailable_date=? AND u.service_id IN (${marks})`,
      [shopId, bookingDate, ...serviceIds],
    );
  } catch (error) {
    if (error.code === "ER_NO_SUCH_TABLE")
      throw Object.assign(
        new Error("Service availability could not be checked right now."),
        { status: 503 },
      );
    throw error;
  }
  if (unavailable.length) {
    const details = unavailable.map((row) => {
      const dateLabel = new Date(`${bookingDate}T12:00:00Z`).toLocaleDateString(
        "en-IN",
        { day: "numeric", month: "long", timeZone: "UTC" },
      );
      return `${row.name} is unavailable on ${dateLabel}${row.reason ? `. Reason: ${row.reason}` : "."}`;
    });
    throw Object.assign(new Error(details.join(" ")), { status: 409 });
  }

  const [offered] = await connection.query(
    `SELECT service_id FROM barber_services WHERE barber_id=? AND service_id IN (${marks})`,
    [barberId, ...serviceIds],
  );
  if (offered.length !== serviceIds.length)
    throw Object.assign(
      new Error("This barber does not offer all selected services."),
      { status: 400 },
    );

  const [users] = await connection.query(
    "SELECT id,name,email FROM users WHERE id=? AND role='customer' AND status='active' LIMIT 1",
    [customerId],
  );
  if (!users.length)
    throw Object.assign(new Error("Customer account not found."), {
      status: 403,
    });

  const amount = services.reduce((sum, x) => sum + Number(x.price), 0);
  const duration = services.reduce(
    (sum, x) => sum + Number(x.duration_minutes),
    0,
  );
  if (!(amount > 0))
    throw Object.assign(new Error("A valid payment amount is required."), {
      status: 400,
    });
  if (!scheduledTime && bookingDate === localDateKey()) {
    const limit = Number(barbers[0].queue_limit || 0);
    const [active] = await connection.query(
      `SELECT COUNT(*) AS total, COALESCE(SUM(duration_minutes),0) AS minutes
       FROM payment_bookings
       WHERE shop_id=? AND barber_id=? AND status='accepted'
         AND queue_status IN ('Waiting','Your Turn','In Service')`,
      [shopId, barberId],
    );
    const expectedWait = Number(active[0].minutes || 0);
    if (Number(active[0].total || 0) >= limit)
      throw Object.assign(
        new Error(
          `Cannot take in queue till for next ${expectedWait} minutes, as queue is full.`,
        ),
        { status: 409 },
      );
    const [nextAppointment] = await connection.query(
      `SELECT scheduled_time FROM payment_bookings
       WHERE shop_id=? AND barber_id=? AND booking_date=? AND scheduled_time IS NOT NULL
         AND (
           status IN ('payment_submitted','accepted')
           AND COALESCE(queue_status, '') NOT IN
             ('Cancelled','Completed','No Show')
         )
         AND scheduled_time > TIME(NOW())
       ORDER BY scheduled_time ASC LIMIT 1`,
      [shopId, barberId, bookingDate],
    );
    if (nextAppointment.length) {
      const now = localTimeKey();
      const toMinutes = (value) =>
        Number(String(value).slice(0, 2)) * 60 +
        Number(String(value).slice(3, 5));
      if (
        expectedWait + duration >
        toMinutes(nextAppointment[0].scheduled_time) - toMinutes(now)
      )
        throw Object.assign(
          new Error(
            `Cannot take in queue till for next ${expectedWait} minutes, as queue is full.`,
          ),
          { status: 409 },
        );
    }
  }
  await validateScheduledSlot(connection, {
    shop: shops[0],
    barberId,
    bookingDate,
    scheduledTime,
    duration,
  });
  return { shop: shops[0], services, customer: users[0], amount, duration };
}

const jsonIds = (value) => {
  if (Array.isArray(value)) return value.map(String);
  try {
    return JSON.parse(value || "[]").map(String);
  } catch {
    return [];
  }
};
const money = (value) =>
  Math.round((Number(value) + Number.EPSILON) * 100) / 100;

async function evaluateScheme(
  connection,
  {
    shopId,
    barberId,
    serviceIds,
    services,
    customerId,
    promoCode,
    schemeId,
    lock = false,
  },
) {
  const code = String(promoCode || "")
    .trim()
    .toUpperCase();
  let sql = `SELECT * FROM schemes WHERE shop_id=? AND status='active'
    AND starts_at<=UTC_TIMESTAMP() AND ends_at>=UTC_TIMESTAMP()`;
  const params = [shopId];
  if (schemeId) {
    sql += " AND id=?";
    params.push(schemeId);
  } else if (code) {
    sql += " AND UPPER(promo_code)=?";
    params.push(code);
  } else sql += " AND promo_code IS NULL";
  sql += lock ? " FOR UPDATE" : "";
  const [candidates] = await connection.query(sql, params);
  if (!candidates.length && code)
    throw Object.assign(
      new Error("This promo code is not active or valid for this booking."),
      { status: 400 },
    );
  if (schemeId && !candidates.length)
    throw Object.assign(
      new Error("This offer is no longer valid. Request a new payment quote."),
      { status: 409 },
    );

  const serviceById = new Map(
    services.map((service) => [String(service.id), service]),
  );
  const baseAmount = money(
    services.reduce((sum, service) => sum + Number(service.price), 0),
  );
  let bestAutomatic = null;
  for (const offer of candidates) {
    const eligibleServiceIds = offer.all_services
      ? serviceIds
      : jsonIds(offer.service_ids_json).filter((id) => serviceById.has(id));
    if (!eligibleServiceIds.length) {
      if (code || schemeId)
        throw Object.assign(
          new Error("This offer does not apply to the selected services."),
          { status: 400 },
        );
      continue;
    }
    if (
      !offer.all_barbers &&
      !jsonIds(offer.barber_ids_json).includes(String(barberId))
    ) {
      if (code || schemeId)
        throw Object.assign(
          new Error("This offer does not apply to the selected barber."),
          { status: 400 },
        );
      continue;
    }
    if (baseAmount < Number(offer.minimum_amount || 0)) {
      if (code || schemeId)
        throw Object.assign(
          new Error(
            `This offer requires a minimum booking amount of ₹${Number(offer.minimum_amount).toFixed(2)}.`,
          ),
          { status: 400 },
        );
      continue;
    }
    const [useRows] = await connection.query(
      `SELECT COUNT(*) AS uses,COALESCE(SUM(customer_id=?),0) AS customer_uses
       FROM payment_bookings WHERE scheme_id=? AND status IN ('payment_submitted','accepted')`,
      [customerId, offer.id],
    );
    const uses = Number(useRows[0]?.uses || 0);
    const customerUses = Number(useRows[0]?.customer_uses || 0);
    if (
      (offer.usage_limit != null && uses >= Number(offer.usage_limit)) ||
      (offer.per_customer_limit != null &&
        customerUses >= Number(offer.per_customer_limit))
    ) {
      if (code || schemeId)
        throw Object.assign(
          new Error("This offer has reached its redemption limit."),
          { status: 409 },
        );
      continue;
    }
    const eligibleSubtotal = money(
      eligibleServiceIds.reduce(
        (sum, id) => sum + Number(serviceById.get(id).price),
        0,
      ),
    );
    let discount =
      offer.discount_type === "percentage"
        ? money((eligibleSubtotal * Number(offer.discount_value)) / 100)
        : Math.min(eligibleSubtotal, Number(offer.discount_value));
    if (offer.maximum_discount != null)
      discount = Math.min(discount, Number(offer.maximum_discount));
    discount = money(Math.min(discount, eligibleSubtotal, baseAmount));
    if (discount >= baseAmount) {
      if (code || schemeId)
        throw Object.assign(
          new Error("This offer cannot reduce the booking to a zero payment."),
          { status: 400 },
        );
      continue;
    }
    if (discount <= 0) {
      if (code || schemeId)
        throw Object.assign(
          new Error(
            "This offer does not provide a discount for the selected services.",
          ),
          { status: 400 },
        );
      continue;
    }
    const eligible = {
      schemeId: offer.id,
      discountAmount: discount,
      originalAmount: baseAmount,
      discountedSubtotal: money(baseAmount - discount),
      promoCode: offer.promo_code || "",
      scheme: {
        id: offer.id,
        title: offer.title,
        discountType: offer.discount_type,
        discountValue: Number(offer.discount_value),
      },
    };
    if (code || schemeId) return eligible;
    if (
      !bestAutomatic ||
      eligible.discountAmount > bestAutomatic.discountAmount
    )
      bestAutomatic = eligible;
  }
  if (bestAutomatic) return bestAutomatic;
  return {
    schemeId: null,
    discountAmount: 0,
    originalAmount: baseAmount,
    discountedSubtotal: baseAmount,
    promoCode: "",
    scheme: null,
  };
}

function requestedBookingDate(value) {
  const date = String(value || "");
  const parsed = /^\d{4}-\d{2}-\d{2}$/.test(date)
    ? new Date(`${date}T00:00:00Z`)
    : null;
  if (
    !parsed ||
    Number.isNaN(parsed.getTime()) ||
    parsed.toISOString().slice(0, 10) !== date
  )
    throw Object.assign(new Error("Select a valid booking date."), {
      status: 400,
    });
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  const today = `${parts.find((x) => x.type === "year").value}-${parts.find((x) => x.type === "month").value}-${parts.find((x) => x.type === "day").value}`;
  if (date < today)
    throw Object.assign(new Error("Choose today or a future booking date."), {
      status: 400,
    });
  return date;
}

function requestedScheduledTime(value, bookingDate) {
  const time = String(value || "").trim();
  if (!time) return null;
  if (bookingDate !== localDateKey())
    throw Object.assign(
      new Error("Same-day scheduling is available for today only."),
      { status: 400 },
    );
  if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time))
    throw Object.assign(new Error("Select a valid appointment time."), {
      status: 400,
    });
  if (time <= localTimeKey())
    throw Object.assign(new Error("Choose a future appointment time."), {
      status: 409,
    });
  return time;
}

async function validateScheduledSlot(
  connection,
  { shop, barberId, bookingDate, scheduledTime, duration },
) {
  if (!scheduledTime) return;
  const availability =
    typeof shop.availability_json === "string"
      ? JSON.parse(shop.availability_json || "{}")
      : shop.availability_json || {};
  const weekday = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Kolkata",
    weekday: "short",
  }).format(new Date(`${bookingDate}T12:00:00Z`));
  const annual = availability.annualSchedules?.[bookingDate];
  const schedule = availability.schedule?.[weekday];
  const shifts = availability.operationalHours?.enabled
    ? [
        {
          open: availability.operationalHours.open,
          close: availability.operationalHours.close,
        },
      ]
    : annual && ["half_day", "special_hours"].includes(annual.type)
      ? [{ open: annual.open, close: annual.close }]
      : schedule?.shifts?.length
        ? schedule.shifts
        : [
            {
              open: schedule?.open || "09:00",
              close: schedule?.close || "21:00",
            },
          ];
  const start =
    Number(scheduledTime.slice(0, 2)) * 60 + Number(scheduledTime.slice(3));
  const end = start + Number(duration);
  const fits = shifts.some((shift) => {
    const open =
      Number(String(shift.open).slice(0, 2)) * 60 +
      Number(String(shift.open).slice(3));
    const close =
      Number(String(shift.close).slice(0, 2)) * 60 +
      Number(String(shift.close).slice(3));
    return start >= open && end <= close;
  });
  if (!fits)
    throw Object.assign(
      new Error(
        "That appointment would fall outside the shop's operating hours.",
      ),
      { status: 409 },
    );
  const [conflicts] = await connection.query(
    `SELECT id FROM payment_bookings
     WHERE shop_id=? AND barber_id=? AND booking_date=? AND scheduled_time IS NOT NULL
       AND (
         status IN ('payment_submitted','accepted')
         AND COALESCE(queue_status, '') NOT IN
           ('Cancelled','Completed','No Show')
       )
       AND scheduled_time < ADDTIME(?, SEC_TO_TIME(duration_minutes * 60))
       AND ADDTIME(scheduled_time, SEC_TO_TIME(? * 60)) > ? LIMIT 1`,
    [shop.id, barberId, bookingDate, scheduledTime, duration, scheduledTime],
  );
  if (conflicts.length)
    throw Object.assign(
      new Error("That time overlaps another scheduled appointment."),
      { status: 409 },
    );
}

async function chooseAmount(connection, shopId, baseAmount) {
  const [rows] = await connection.query(
    `SELECT amount FROM payment_bookings
     WHERE shop_id=? AND status='payment_submitted'
       AND created_at > (NOW() - INTERVAL ${AMOUNT_WINDOW_MINUTES} MINUTE)`,
    [shopId],
  );

  const used = new Set(rows.map((r) => Number(r.amount).toFixed(2)));
  let amount = Math.round(Number(baseAmount) * 100) / 100;
  while (used.has(amount.toFixed(2)))
    amount = Math.round((amount + 0.01) * 100) / 100;
  return amount;
}

async function expireStalePending(connection, customerId, beneficiaryKey) {
  await connection.query(
    `UPDATE payment_bookings
     SET status='cancelled', decline_reason='Confirmation window expired'
     WHERE customer_id=? AND beneficiary_key=? AND status='payment_submitted'
       AND created_at <= (NOW() - INTERVAL 15 MINUTE)`,
    [customerId, beneficiaryKey],
  );
}

function responsePayload(booking, shop, services) {
  return {
    bookingId: booking.id,
    amount: Number(booking.amount),
    currency: "INR",
    qrUrl: shop.upi_qr_url,
    shopName: shop.name,
    description: services.map((x) => x.name).join(", "),
  };
}

// Read-only quote used by the pay screen. The actual submit endpoint recalculates everything again.
export async function paymentQuote(req, res) {
  const connection = await pool.getConnection();
  try {
    const customerId = req.user.sub;
    const shopId = String(req.body?.shopId || "");
    const barberId = String(req.body?.barberId || "");
    let bookingDate;
    try {
      bookingDate = requestedBookingDate(req.body?.bookingDate);
    } catch (error) {
      return res.status(error.status).json({ message: error.message });
    }
    let scheduledTime;
    try {
      scheduledTime = requestedScheduledTime(
        req.body?.scheduledTime,
        bookingDate,
      );
    } catch (error) {
      return res.status(error.status).json({ message: error.message });
    }
    const serviceIds = [
      ...new Set(
        (Array.isArray(req.body?.serviceIds) ? req.body.serviceIds : []).map(
          String,
        ),
      ),
    ].sort();
    if (!shopId || !barberId || !serviceIds.length)
      return res.status(400).json({
        message: "Shop, barber and at least one service are required.",
      });

    const { shop, services, customer, amount } = await validateSelection(
      connection,
      { shopId, barberId, serviceIds, customerId, bookingDate, scheduledTime },
    );
    const who = beneficiaryFrom(req.body, customer);
    if (who.error) return res.status(400).json({ message: who.error });

    await expireStalePending(connection, customerId, who.key);

    const [pending] = await connection.query(
      "SELECT id FROM payment_bookings WHERE customer_id=? AND beneficiary_key=? AND status='payment_submitted' LIMIT 1",
      [customerId, who.key],
    );
    if (pending.length)
      return res.status(409).json({
        message: "You already have a payment waiting for this booking.",
        bookingId: pending[0].id,
      });

    const [blocked] = await connection.query(
      "SELECT id FROM payment_bookings WHERE shop_id=? AND customer_id=? AND status='rejected' AND declined_until > NOW() ORDER BY declined_until DESC LIMIT 1",
      [shopId, customerId],
    );
    if (blocked.length)
      return res.status(429).json({
        message:
          "This booking cannot be retried for 30 minutes after a declined payment.",
        bookingId: blocked[0].id,
      });

    const applied = await evaluateScheme(connection, {
      shopId,
      barberId,
      serviceIds,
      services,
      customerId,
      promoCode: req.body?.promoCode,
    });
    const finalAmount = await chooseAmount(
      connection,
      shopId,
      applied.discountedSubtotal,
    );
    const quotePayload = {
      customerId,
      shopId,
      barberId,
      serviceIds,
      bookingDate,
      scheduledTime,
      beneficiaryKey: who.key,
      amount: finalAmount,
      originalAmount: applied.originalAmount,
      discountAmount: applied.discountAmount,
      schemeId: applied.schemeId,
      promoCode: applied.promoCode,
      discountedSubtotal: applied.discountedSubtotal,
      qrUrl: shop.upi_qr_url,
      exp: Date.now() + AMOUNT_WINDOW_MINUTES * 60 * 1000,
    };
    res.json({
      ...responsePayload({ id: null, amount: finalAmount }, shop, services),
      originalAmount: applied.originalAmount,
      discountAmount: applied.discountAmount,
      scheme: applied.scheme,
      quoteToken: signQuote(quotePayload),
    });
  } catch (error) {
    res
      .status(error.status || 500)
      .json({ message: error.message || "Could not prepare payment." });
  } finally {
    connection.release();
  }
}

// The customer only reaches this endpoint after paying the exact amount shown on the pay screen.
// The server recalculates prices, beneficiary rules, duplicate rules and the amount before creating the booking.
export async function submitPayment(req, res) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const customerId = req.user.sub;
    const shopId = String(req.body?.shopId || "");
    const barberId = String(req.body?.barberId || "");
    const bookingDate = requestedBookingDate(req.body?.bookingDate);
    const scheduledTime = requestedScheduledTime(
      req.body?.scheduledTime,
      bookingDate,
    );
    const serviceIds = [
      ...new Set(
        (Array.isArray(req.body?.serviceIds) ? req.body.serviceIds : []).map(
          String,
        ),
      ),
    ].sort();
    if (!shopId || !barberId || !serviceIds.length)
      throw Object.assign(
        new Error("Shop, barber and at least one service are required."),
        { status: 400 },
      );

    // Serialize submissions for the same customer so a double-click cannot create two pending bookings.
    const [customerRows] = await connection.query(
      "SELECT id FROM users WHERE id=? AND role='customer' AND status='active' FOR UPDATE",
      [customerId],
    );
    if (!customerRows.length)
      throw Object.assign(new Error("Customer account not found."), {
        status: 403,
      });

    const {
      shop,
      services,
      customer,
      amount: baseAmount,
      duration,
    } = await validateSelection(connection, {
      shopId,
      barberId,
      serviceIds,
      bookingDate,
      customerId,
      scheduledTime,
    });
    const who = beneficiaryFrom(req.body, customer);
    if (who.error) throw Object.assign(new Error(who.error), { status: 400 });

    await expireStalePending(connection, customerId, who.key);

    const [pending] = await connection.query(
      "SELECT id FROM payment_bookings WHERE customer_id=? AND beneficiary_key=? AND status='payment_submitted' LIMIT 1",
      [customerId, who.key],
    );
    if (pending.length)
      throw Object.assign(
        new Error("You already have a payment waiting for the shop."),
        { status: 409, bookingId: pending[0].id },
      );

    const [blocked] = await connection.query(
      "SELECT id FROM payment_bookings WHERE shop_id=? AND customer_id=? AND status='rejected' AND declined_until > NOW() ORDER BY declined_until DESC LIMIT 1",
      [shopId, customerId],
    );
    if (blocked.length)
      throw Object.assign(
        new Error(
          "This booking cannot be retried for 30 minutes after a declined payment.",
        ),
        { status: 429, bookingId: blocked[0].id },
      );

    const quote = verifyQuote(req.body?.quoteToken);
    const selectionMatches =
      quote &&
      quote.customerId === customerId &&
      quote.shopId === shopId &&
      quote.barberId === barberId &&
      quote.bookingDate === bookingDate &&
      quote.scheduledTime === scheduledTime &&
      quote.beneficiaryKey === who.key &&
      quote.qrUrl === shop.upi_qr_url &&
      JSON.stringify(quote.serviceIds) === JSON.stringify(serviceIds);
    if (!selectionMatches)
      throw Object.assign(
        new Error(
          "Payment amount could not be verified. Reopen the payment screen and try again.",
        ),
        { status: 400 },
      );

    const applied = await evaluateScheme(connection, {
      shopId,
      barberId,
      serviceIds,
      services,
      customerId,
      promoCode: quote.promoCode,
      schemeId: quote.schemeId,
      lock: Boolean(quote.schemeId),
    });
    if (
      money(applied.originalAmount) !== money(quote.originalAmount) ||
      money(applied.discountAmount) !== money(quote.discountAmount) ||
      money(applied.discountedSubtotal) !== money(quote.discountedSubtotal)
    )
      throw Object.assign(
        new Error(
          "Offer eligibility or discount changed. Reopen the payment screen for an updated quote.",
        ),
        { status: 409 },
      );

    const finalAmount = Number(quote.amount);
    if (!Number.isFinite(finalAmount) || finalAmount <= 0)
      throw Object.assign(new Error("Invalid payment amount."), {
        status: 400,
      });

    const bookingId = crypto.randomUUID();
    const requestHash = sha256(
      [
        shopId,
        barberId,
        serviceIds.join(","),
        bookingDate,
        scheduledTime || "",
        scheduledTime,
        who.key,
        finalAmount.toFixed(2),
      ].join("|"),
    );

    const [recentSame] = await connection.query(
      `SELECT id FROM payment_bookings
       WHERE customer_id=? AND request_hash=? AND status='payment_submitted'
         AND created_at > (NOW() - INTERVAL ${REBOOK_BLOCK_MINUTES} MINUTE)
       LIMIT 1`,
      [customerId, requestHash],
    );
    if (recentSame.length)
      throw Object.assign(
        new Error(
          "This payment submission is already being checked by the shop.",
        ),
        { status: 409, bookingId: recentSame[0].id },
      );

    await connection.query(
      `INSERT INTO payment_bookings
   (
     id, shop_id, barber_id, customer_id, booking_date, scheduled_time, service_ids_json,
     amount, original_amount, discount_amount, scheme_id, duration_minutes, beneficiary_json, beneficiary_key,
     request_hash, payment_method, status, payer_name, payment_submitted_at
   )
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        bookingId,
        shopId,
        barberId,
        customerId,
        bookingDate,
        scheduledTime,
        JSON.stringify(serviceIds),
        finalAmount,
        applied.originalAmount,
        applied.discountAmount,
        applied.schemeId,
        duration,
        JSON.stringify(who.person),
        who.key,
        requestHash,
        "upi_qr",
        "payment_submitted",
        String(req.body?.payerName || "")
          .trim()
          .slice(0, 120) || customer.name,
      ],
    );

    await connection.commit();

    const rows = await findBookings("b.id=?", [bookingId], "LIMIT 1");
    const hydrated = await hydrateBookings(rows);
    const booking = hydrated[0];

    if (!booking) {
      throw Object.assign(
        new Error("Booking was created but could not be loaded."),
        { status: 500 },
      );
    }
    const payer = booking.payerName || booking.customerName;
    const bookedFor =
      booking.beneficiary?.isSelf === false
        ? `for ${booking.beneficiary.name}, booked by ${booking.customerName}`
        : booking.customerName;

    await addNotification({
      shopId,
      tone: "info",
      refId: bookingId,
      text: `New payment submitted: ${rupees(booking.amount)} by ${payer} for ${bookedFor}. ${booking.services.map((x) => x.name).join(" + ")} with ${booking.barberName}.`,
    });

    await addNotification({
      userId: customerId,
      tone: "info",
      refId: bookingId,
      text: `Payment submitted for ${rupees(booking.amount)} at ${booking.shopName}. The shop is checking your payment.`,
    });

    res.status(201).json({ booking });
  } catch (error) {
    console.log(error);
    await connection.rollback().catch(() => {});
    res.status(error.status || 500).json({
      message: error.message || "Could not submit the payment.",
      bookingId: error.bookingId,
      amount: error.amount,
    });
  } finally {
    connection.release();
  }
}
