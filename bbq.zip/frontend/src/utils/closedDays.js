import { to12Hour } from "./time.js";

export const ALL_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const JS_DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
// availability.days is the list of OPEN days. A day missing from the list is a "Close Shop" day.
// Shops saved before this option existed have no list, so they stay open every day.
const SHOP_TIME_ZONE = "Asia/Kolkata";
const shopDateParts = (date = new Date()) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: SHOP_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
export const toLocalDateString = (d = new Date()) => {
  const parts = shopDateParts(d);
  const get = (type) => parts.find((part) => part.type === type)?.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
};

export const formatDateDisplay = (str, includeYear = false) => {
  if (!str) return "";
  try {
    const [y, m, d] = str.split("-").map(Number);
    if (!y || !m || !d) return str;
    const date = new Date(y, m - 1, d);
    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      ...(includeYear ? { year: "numeric" } : {}),
    });
  } catch {
    return str;
  }
};

export const getTemporaryClosure = (shop, date = new Date()) => {
  const tc = shop?.availability?.temporaryClosure;
  if (!tc || !tc.active) return { isClosed: false };

  const current = toLocalDateString(date);
  if (tc.startAt || tc.endAt) {
    const start = tc.startAt ? new Date(tc.startAt) : null;
    const end = tc.endAt ? new Date(tc.endAt) : null;
    if (start && date < start)
      return { isClosed: false, upcoming: true, startAt: tc.startAt, endAt: tc.endAt, reason: String(tc.reason || "").trim() };
    if (end && date >= end)
      return { isClosed: false, expired: true, startAt: tc.startAt, endAt: tc.endAt };
    return {
      isClosed: true,
      startAt: tc.startAt,
      endAt: tc.endAt,
      startDate: tc.startDate || tc.startAt?.slice(0, 10),
      endDate: tc.endDate || tc.endAt?.slice(0, 10),
      reason: String(tc.reason || "").trim(),
    };
  }
  const start = tc.startDate || current;
  const end = tc.endDate || "";

  if (current < start) {
    return {
      isClosed: false,
      upcoming: true,
      startDate: start,
      endDate: end,
      reason: String(tc.reason || "").trim(),
    };
  }

  if (end && current > end) {
    return { isClosed: false, expired: true };
  }

  return {
    isClosed: true,
    startDate: start,
    endDate: end,
    reason: String(tc.reason || "").trim(),
  };
};

export const annualSchedulesOf = (shopOrAvailability) => {
  const availability = shopOrAvailability?.availability || shopOrAvailability || {};
  const saved = availability?.annualSchedules;
  if (!saved || typeof saved !== "object") return {};
  return Object.fromEntries(
    Object.entries(saved)
      .filter(([date]) => /^\d{4}-\d{2}-\d{2}$/.test(date))
      .map(([date, item]) => [
        date,
        {
          type: ["closed", "half_day", "special_hours"].includes(item?.type)
            ? item.type
            : "closed",
          open: String(item?.open || "09:00").slice(0, 5),
          close: String(item?.close || "21:00").slice(0, 5),
          note: String(item?.note || "").slice(0, 200),
        },
      ]),
  );
};

export const annualScheduleForDate = (shop, date = new Date()) =>
  annualSchedulesOf(shop)[
    typeof date === "string" ? date : toLocalDateString(date)
  ] || null;

export const MAX_SHIFTS_PER_DAY = 6;

export const normalizeDayShifts = (dayObj) => {
  if (Array.isArray(dayObj?.shifts) && dayObj.shifts.length > 0) {
    return dayObj.shifts.slice(0, MAX_SHIFTS_PER_DAY).map((s) => ({
      open: String(s?.open || "09:00").slice(0, 5),
      close: String(s?.close || "21:00").slice(0, 5),
    }));
  }
  return [
    {
      open: String(dayObj?.open || "09:00").slice(0, 5),
      close: String(dayObj?.close || "21:00").slice(0, 5),
    },
  ];
};

export const formatShiftDisplay = (s) => {
  const o = to12Hour(s?.open || "09:00");
  const c = to12Hour(s?.close || "21:00");
  return `${o.time} ${o.period} - ${c.time} ${c.period}`;
};

export const openDaysOf = (shop) =>
  Array.isArray(shop?.availability?.days) ? shop.availability.days : ALL_DAYS;
export const isClosedToday = (shop, date = new Date()) =>
  !openDaysOf(shop).includes(JS_DAY[date.getDay()]);

const tcEnded = (shop, date = new Date()) => {
  const end = shop?.availability?.temporaryClosure?.endAt;
  return Boolean(end && new Date(end) <= date);
};

export const isShopOpenNow = (shop, date = new Date()) => {
  if (getTemporaryClosure(shop, date).isClosed) return false;
  const manualOpen = shop?.availability?.isOpen === true;
  const annual = annualScheduleForDate(shop, date);
  if (annual?.type === "closed" && !manualOpen) return false;
  const openFlag =
    shop?.availability?.isOpen !== undefined
      ? shop.availability.isOpen
      : shop?.open !== undefined
        ? shop.open
        : shop?.isOpen !== undefined
          ? shop.isOpen
          : true;
  const expiredEmergency =
    shop?.availability?.emergencyClosed &&
    tcEnded(shop, date);
  if ((!openFlag && !expiredEmergency) || (!manualOpen && isClosedToday(shop, date))) return false;

  const weekday = new Intl.DateTimeFormat("en-US", {
    timeZone: SHOP_TIME_ZONE,
    weekday: "short",
  }).format(date);
  const d = weekday;
  const sched = scheduleOf(shop)[d];
  if (!sched || (sched.closed && !manualOpen)) return false;

  const timeParts = new Intl.DateTimeFormat("en-GB", {
    timeZone: SHOP_TIME_ZONE,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const currentH = timeParts.find((part) => part.type === "hour")?.value;
  const currentM = timeParts.find((part) => part.type === "minute")?.value;
  const now = `${currentH}:${currentM}`;
  if (manualOpen) return true;

  const override = shop?.availability?.operationalHours;
  if (
    override?.enabled &&
    (!override.date || override.date === toLocalDateString(date)) &&
    /^\d{2}:\d{2}$/.test(String(override.open)) &&
    /^\d{2}:\d{2}$/.test(String(override.close))
  ) {
    return now >= override.open && now < override.close;
  }

  if (annual && ["half_day", "special_hours"].includes(annual.type)) {
    return now >= annual.open && now < annual.close;
  }

  const shifts = normalizeDayShifts(sched);
  return shifts.some((s) => now >= s.open && now < s.close);
};

// ---- Per-day schedule: availability.schedule = { Mon: { open: "09:00", close: "21:00", closed: false, shifts: [...] }, ... }
export const defaultSchedule = (open = "09:00", close = "21:00") =>
  Object.fromEntries(
    ALL_DAYS.map((d) => [
      d,
      {
        open,
        close,
        closed: false,
        shifts: [{ open, close }],
      },
    ]),
  );

export const scheduleOf = (shop) => {
  const saved = shop?.availability?.schedule;
  const hours = shop?.hours || {};
  const base = defaultSchedule(
    String(hours.open || "09:00").slice(0, 5),
    String(hours.close || "21:00").slice(0, 5),
  );
  if (saved && typeof saved === "object") {
    return Object.fromEntries(
      ALL_DAYS.map((d) => {
        const item = saved[d] || {};
        const shifts = normalizeDayShifts({ ...base[d], ...item });
        const earliest = shifts[0]?.open || item.open || base[d].open;
        const latest =
          shifts[shifts.length - 1]?.close || item.close || base[d].close;
        return [
          d,
          {
            ...base[d],
            ...item,
            open: earliest,
            close: latest,
            shifts,
          },
        ];
      }),
    );
  }
  const days = openDaysOf(shop);
  return Object.fromEntries(
    ALL_DAYS.map((d) => [
      d,
      {
        ...base[d],
        closed: !days.includes(d),
        shifts: normalizeDayShifts(base[d]),
      },
    ]),
  );
};

// Keep the old fields in sync so everything that reads availability.days / hours keeps working.
export const withSchedule = (availability = {}, schedule) => {
  const normalizedSchedule = Object.fromEntries(
    ALL_DAYS.map((d) => {
      const item = schedule[d] || {};
      const shifts = normalizeDayShifts(item);
      const earliest = shifts[0]?.open || item.open || "09:00";
      const latest =
        shifts[shifts.length - 1]?.close || item.close || "21:00";
      return [
        d,
        {
          ...item,
          open: earliest,
          close: latest,
          shifts,
        },
      ];
    }),
  );
  return {
    ...availability,
    schedule: normalizedSchedule,
    days: ALL_DAYS.filter((d) => !normalizedSchedule[d].closed),
  };
};

export const hoursFromSchedule = (schedule) => {
  const first = ALL_DAYS.find((d) => !schedule[d]?.closed) || "Mon";
  const item = schedule[first] || {};
  const shifts = normalizeDayShifts(item);
  return {
    open: shifts[0]?.open || item.open || "09:00",
    close: shifts[shifts.length - 1]?.close || item.close || "21:00",
  };
};

export const scheduleError = (schedule) => {
  if (ALL_DAYS.every((d) => schedule[d]?.closed))
    return "Keep at least one day open.";

  for (const d of ALL_DAYS) {
    const day = schedule[d];
    if (day?.closed) continue;

    if (Array.isArray(day?.shifts) && day.shifts.length > MAX_SHIFTS_PER_DAY) {
      return `${d}: Maximum ${MAX_SHIFTS_PER_DAY} shifts allowed per day.`;
    }

    const shifts = normalizeDayShifts(day);
    if (!shifts.length) {
      return `${d}: Add at least one shift or mark the day as closed.`;
    }

    for (let i = 0; i < shifts.length; i++) {
      const s = shifts[i];
      if (s.close <= s.open) {
        return `${d} Shift ${i + 1}: Closing time must be after opening time.`;
      }
    }

    // Check for overlapping shifts
    for (let i = 0; i < shifts.length; i++) {
      for (let j = i + 1; j < shifts.length; j++) {
        const a = shifts[i];
        const b = shifts[j];
        if (a.open < b.close && b.open < a.close) {
          return `${d}: This time slot overlaps with another shift. Please select a different time (Shift ${i + 1} and Shift ${j + 1}).`;
        }
      }
    }
  }

  return "";
};

export const todayHoursText = (shop, date = new Date()) => {
  const annual = annualScheduleForDate(shop, date);
  if (annual?.type === "closed") {
    return annual.note ? `Closed: ${annual.note}` : "Closed";
  }
  if (annual && ["half_day", "special_hours"].includes(annual.type)) {
    const label = annual.type === "half_day" ? "Half day" : "Special hours";
    return `${label}: ${formatShiftDisplay(annual)}${annual.note ? ` (${annual.note})` : ""}`;
  }
  const d = JS_DAY[date.getDay()];
  const e = scheduleOf(shop)[d];
  if (e.closed) return `${d}: Closed`;
  const shifts = normalizeDayShifts(e);
  return `${d}: ${shifts.map(formatShiftDisplay).join(", ")}`;
};
